-- 9.	Write a SQL query which produces a table containing unique countries and their average news_guard_score.

