-- 6.	Write a SQL query which produces a table containing the average news_guard_score for the data set.

