-- 3.	Write a SQL query which produces a table containing the title and month of each article. 

