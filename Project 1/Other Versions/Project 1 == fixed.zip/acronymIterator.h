//
// Project 1
// CS 341 Spring 2021
// << Your Name Here >>
//
//Populate this file with the functions definitions for the acronymIterator class

#pragma once
#include "characterParser.h"
#include <iterator>

class characterParser::acronymIterator
{
	acronymIterator();

};


