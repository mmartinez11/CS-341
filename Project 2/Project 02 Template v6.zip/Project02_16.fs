module Project02_16

open utils
//open Project02_15 // you can import functions from a previous project
//
// Primes t
// returns all the primes from 1 to t in a list, in ascending order.
// You can assume the input is greater than 0.
//
// Examples:
//          Primes 1 => []
//          Primes 2 => [2]
//          Primes 4 => [2;3]
//          Primes 11 => [2;3;5;7;11]
//



let rec Primes t =
    []      //   TO BE IMPLEMENTED


//[<EntryPoint>]
let main argv =
    printfn "Testing Exercise 16: Primes"

    test (lazy (Primes 1)) [] NoException
    test (lazy (Primes 2)) [2] NoException
    test (lazy (Primes 4)) [2;3] NoException
    test (lazy (Primes 11)) [2;3;5;7;11] NoException
                
    printfn ""
    0 // return an integer exit code
    

