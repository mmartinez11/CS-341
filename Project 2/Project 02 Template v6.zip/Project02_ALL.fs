module Project02

// Function 1

let max L =
    List.head L   //   TO BE IMPLEMENTED
    

// Function 2


let min L =
    List.head L      //   TO BE IMPLEMENTED


// Function 3

let rec nth L n =
    List.head L      //   TO BE IMPLEMENTED


// Function 4

let rec find L item =
    0         //   TO BE IMPLEMENTED


// Function 5

let rec count L item =
    0        // TO BE IMPLEMENTED


// Function 6

let map F L =
    []     //   TO BE IMPLEMENTED


// Function 7

let iter F L =
    ()      //   TO BE IMPLEMENTED


// Function 8

let reduce F L =
    List.head L      //   TO BE IMPLEMENTED


// Function 9

let rec fold F start L =
    start        //   TO BE IMPLEMENTED


// Function 10

let flatten L =
    []         //   TO BE IMPLEMENTED


// Function 11

let zip L1 L2 =
    []         //   TO BE IMPLEMENTED


// Function 12

let unzip L =
    ([],[])     //   TO BE IMPLEMENTED


// Function 13

let rec GCD A B =
    0         //   TO BE IMPLEMENTED


// Function 14

let GCDList L =
    0       //   TO BE IMPLEMENTED


// Function 15

let isPrime i =
    false         //   TO BE IMPLEMENTED


// Function 16

let rec Primes t =
    []      //   TO BE IMPLEMENTED


// Function 17

let isMatch str =
    false         //   TO BE IMPLEMENTED


// Function 18

let firstMatch s =
    ""          //   TO BE IMPLEMENTED


// Function 19

let allMatches s = 
    []             //   TO BE IMPLEMENTED


// Function 20

let rec RegEx s pattern =
    true         //    TO BE IMPLEMENTED




















