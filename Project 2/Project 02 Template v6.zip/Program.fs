﻿module main

open System
//open Project02  // uncomment to use functions in the _ALL file in this file

[<EntryPoint>]
let main argv =
    printfn "Uncomment the lines in Program.fs as you want to test your functions"
    // uncomment a line if you're ready to test the function in that file
    // comment out a line if you don't want to execute it
    //ignore (Project02_01.main [])
    //ignore (Project02_02.main [])
    //ignore (Project02_03.main [])
    //ignore (Project02_04.main [])
    //ignore (Project02_05.main [])
    //ignore (Project02_06.main [])
    //ignore (Project02_07.main [])
    //ignore (Project02_08.main [])
    //ignore (Project02_09.main [])
    //ignore (Project02_10.main [])
    //ignore (Project02_11.main [])
    //ignore (Project02_12.main [])
    //ignore (Project02_13.main [])
    //ignore (Project02_14.main [])
    //ignore (Project02_15.main [])
    //ignore (Project02_16.main [])
    //ignore (Project02_17.main [])
    //ignore (Project02_18.main [])
    //ignore (Project02_19.main [])
    //ignore (Project02_20.main [])
    0 // return an integer exit code
